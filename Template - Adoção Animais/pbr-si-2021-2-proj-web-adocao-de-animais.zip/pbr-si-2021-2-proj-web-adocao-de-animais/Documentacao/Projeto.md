# Informações do Projeto
`TÍTULO DO PROJETO`  

Trabalho Interdisciplinar - Aplicacões Web

`CURSO`

`SEMESTRE`

## Participantes

Os membros do grupo são: 
- Fulano da Silva
- Ciclano Albuquerque

> Inclua a lista dos membros da equipe com seus nomes completos.

# Estrutura do Documento

1. [Contexto](1-Contexto.md)
2. [Especificações do Projeto](2-Especificação.md)
3. [Projeto da Interface](3-Interface.md)
4. [Gestão de Configuração](4-Gestão-Configuração.md)
5. [Gerenciamento de Projeto](5-Gerenciamento-Projeto.md)
6. [Implementação](6-Implementação.md)
7. [Testes e Avaliação](7-Testes.md)
8. [Referências](8-Referências.md)
9. [Apresentação](9-Apresentação.md)