# BH Adota Pet

O objetivo é a criação de um portal de adoção de animais que apresente ferramentas de fácil uso e que permita a integração dos agentes envolvidos no processo de adoção, resgate e doação de animais

## Alunos integrantes da equipe

* Daniel Cima Bittarães
* Roberta Giovana Soares 
* Eliabner Teixeira Marques
* Jêniffer Camila Gonçalves Rocha
* Guilherme Lopes Fogli Cota

## Professores responsáveis

* Ivre Marjorie Ribeiro Machado
* Sandra Maria Silveira

## Instruções de utilização

Assim que a primeira versão do sistema estiver disponível, deverá complementar com as instruções de utilização. Descreva como instalar eventuais dependências e como executar a aplicação.
